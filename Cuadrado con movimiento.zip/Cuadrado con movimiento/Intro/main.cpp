#include"include/SDL.h"
#include<iostream>
#pragma comment( lib,"SDL/libx86/SDL2.lib" )
#pragma comment( lib,"SDL/libx86/SDL2main.lib" )
#define NUMBULLET 20
#define MASK 255,255,255

int main(int argc,char* argv[]) {
	SDL_Init(SDL_INIT_EVERYTHING);
	int h = 720;
	int w = 720;
	bool up = false;
	bool down = false;
	bool left = false;
	bool right = false;
	bool bulletmov = false;
	SDL_Window *MainWindow = SDL_CreateWindow("Projecte 1",
		SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
		w, h, SDL_WINDOW_SHOWN);
	
	SDL_Texture* ship = nullptr;
	SDL_Renderer *renderer = SDL_CreateRenderer(MainWindow, -1, SDL_RENDERER_PRESENTVSYNC);
	ship = SDL_CreateTextureFromSurface(renderer, SDL_LoadBMP("spaceship1.bmp"));
	/*SDL_SetColorKey(ship, SDL_SRCCOLORKEY, SDL_MapRGB(ship->format, MASK));*/
	

	SDL_Rect square; 
	square.x = 225;
	square.y = 225;
	square.w = 50;
	square.h = 50;

	SDL_Rect bullet[NUMBULLET];
	int i = 0;
	for ( i = 0; i < NUMBULLET; i++) {
		bullet[i].x = -50;
		bullet[i].y = -50;
		bullet[i].w = 50;
		bullet[i].h = 5;
	}
	i = 0;
	
	
	
	




	
	//SDL_Delay(5000); // Que la pantalla tardi uns segons en tancar
	while (1) {
		SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
		SDL_RenderClear(renderer); // Borro el que hi havia i creo pantalla vermella
		for (int k = 0; k < NUMBULLET; k++) {
			SDL_SetRenderDrawColor(renderer, 0, 155, 0, 255); //Li apliques el color
			SDL_RenderFillRect(renderer, &bullet[k]);
		}
		SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255); //Li apliques el color
		SDL_RenderFillRect(renderer, &square);
		
		

		SDL_Event event;
		while (SDL_PollEvent(&event)) {
			if (event.type == SDL_KEYDOWN  && event.key.repeat == 0) {
				switch (event.key.keysym.sym) {
				case SDLK_LEFT:
					left = true;
					break;
				case SDLK_RIGHT:
					right = true;
					break;
				case SDLK_UP:
					up = true;
					break;
				case SDLK_DOWN:
					down = true;
					break;
				case SDLK_SPACE:
					bulletmov = true;
					break;
				case SDLK_ESCAPE: //Tancar amb el Escape
					SDL_Quit;
					return EXIT_SUCCESS;
				default:
					printf("No valid\n");
					break;
				}
				
			}
			else if (event.type == SDL_QUIT) { //Tancar amb la creu
				SDL_Quit;
				return EXIT_SUCCESS;
				break;
				
				}
			else if (event.type == SDL_KEYUP) {
				switch (event.key.keysym.sym) {
				case SDLK_LEFT:
					left = false;
					break;
				case SDLK_RIGHT:
					right = false;
					break;
				case SDLK_UP:
					up = false;
					break;
				case SDLK_DOWN:
					down = false;
					break;
				default:
					printf("No valid\n");
					break;
				}
			}
			}
			
	if (up == true) {
		square.y -= 10;
		if (square.y < 0)
		{
			square.y = 0;
		}
	}
	if (down == true) {
		square.y += 10;
		if (square.y >(h - square.h))
		{
			square.y = (h - square.h);
		}
	}
	if (left == true) {
		square.x -= 10;
		if (square.x < 0)
		{
			square.x = 0;
		}
	}
	if (right == true) {
		square.x += 10;
		if (square.x >(w - square.w))
		{
			square.x = (w - square.w);
		}
	}
	
	

	if (bulletmov == true) {
		bullet[i].x = square.x;
		bullet[i].y = square.y;
		i++;
			bulletmov = false;
	}
	for (int j = 0; j < NUMBULLET; j++) {
		bullet[j].x += 10;
	}
	if (i >= NUMBULLET - 1) {
		i = 0;
	}
	SDL_RenderCopy(renderer, ship, NULL, &square);
		SDL_RenderPresent(renderer); //Para que se actualize lo que se ha escrito
	}
	

}